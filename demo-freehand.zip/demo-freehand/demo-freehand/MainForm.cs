﻿/*
 * Created by SharpDevelop.
 * User: uu
 * Date: 2020/9/21
 * Time: 9:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace demo_freehand
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		public DRAW_OPERATION _idrawop=DRAW_OPERATION.DO_INIT;
		List<Point> _pts_freehand=new List<Point>();
		
		void PictureBox1Paint(object sender, PaintEventArgs e)
		{
			if(_pts_freehand.Count < 2) return;
			
			Graphics g=e.Graphics;
			Pen  pred=new Pen(Color.Red,3);
			             
			g.DrawLines(pred,_pts_freehand.ToArray());
	
		}
		void PictureBox1MouseDown(object sender, MouseEventArgs e)
		{
			if(e.Button != MouseButtons.Left) return;
			
			switch(_idrawop)
			{
				case DRAW_OPERATION.DO_FREEHAND:
					_pts_freehand.Clear();
					_pts_freehand.Add(e.Location);
					break;
					
			}
		}
		void PictureBox1MouseMove(object sender, MouseEventArgs e)
		{
			toolStripStatusLabel3.Text = string.Format("{0},{1}",e.X,e.Y);
			
			if(e.Button != MouseButtons.Left) return;
			
			switch(_idrawop)
			{
				case DRAW_OPERATION.DO_FREEHAND:
					int icnt = _pts_freehand.Count-1;
					if(icnt < 0) return;
					Point ptend=_pts_freehand[icnt];
					
					Graphics g=pictureBox1.CreateGraphics();
					Pen pggg = new Pen(Color.Yellow,2);
					g.DrawLine(pggg, ptend, e.Location);
					g.Dispose();
					
					_pts_freehand.Add(e.Location);
					break;
					
			}
			
		}
		void PictureBox1MouseUp(object sender, MouseEventArgs e)
		{
			if(e.Button != MouseButtons.Left) return;
			
			switch(_idrawop)
			{
				case DRAW_OPERATION.DO_FREEHAND:
					_pts_freehand.Add(e.Location);
					pictureBox1.Refresh();
					break;
					
			}
		}
		void 自由绘制ToolStripMenuItemClick(object sender, EventArgs e)
		{
			_idrawop = DRAW_OPERATION.DO_FREEHAND;
		}
		void 打开ToolStripMenuItemClick(object sender, EventArgs e)
		{
			if(	openFileDialog1.ShowDialog() == DialogResult.Cancel)
				return;
			
			string sname=openFileDialog1.FileName;
			if(!File.Exits(sname))
				return;
			
			//读文件
		}
	}
	
	
	public enum DRAW_OPERATION {
		DO_INIT=0,
		DO_DOT,
		DO_PLINE,
		DO_POLYGON,
		DO_CIRCLE,
		DO_RECT,
		DO_FREEHAND
	}
}
